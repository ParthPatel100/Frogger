CPSC 359 Project Part 1 README
Team Members: 
Parth Patel - 30096473
Shailly Patel - 30088139

To compile the project part 1 code:
  -open terminal
  -go to the directory the project is saved
  -type "make" to compile the code
  -type "make run" OR "./myProg" to run the project code
  -the program will now be running user can continue pressing buttons on SNES controller OR press 'start' button to terminate program
  
NOTE: The SNES Controller is highly sensitive. At times, pressing the button might show user pressed it twice. 
